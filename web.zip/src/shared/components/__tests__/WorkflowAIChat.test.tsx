import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import type { ChatMessage } from '@/shared/types/chat';
import { WorkflowAIChat } from '../WorkflowAIChat';

const mockSendMessage = vi.fn();
const mockConfirmPending = vi.fn();
const mockUseWorkflowAI = vi.fn();

vi.mock('@/hooks/useWorkflowAI', () => ({
  useWorkflowAI: (...args: unknown[]) => mockUseWorkflowAI(...args),
}));

const createDefaultHookReturn = () => ({
  messages: baseMessages,
  isProcessing: false,
  pendingWorkflow: null,
  sendMessage: mockSendMessage,
  confirmPendingWorkflow: mockConfirmPending,
  errorMessage: null as string | null,
});

const baseMessages: ChatMessage[] = [
  { id: 'user-1', role: 'user', content: 'hello', timestamp: Date.now() },
  { id: 'assistant-1', role: 'assistant', content: 'hi there', timestamp: Date.now() },
];

const setupHookReturn = (overrides: Partial<ReturnType<typeof createDefaultHookReturn>> = {}) => {
  const result = { ...createDefaultHookReturn(), ...overrides };
  mockUseWorkflowAI.mockReturnValue(result);
  return result;
};

describe('WorkflowAIChat', () => {
  const workflowId = 'wf_test123';
  const onWorkflowUpdate = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
    setupHookReturn();
  });

  it('renders chat UI and messages from hook', () => {
    render(<WorkflowAIChat workflowId={workflowId} onWorkflowUpdate={onWorkflowUpdate} />);

    expect(screen.getByPlaceholderText(/������Ϣ/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /����/i })).toBeInTheDocument();
    expect(screen.getByText('hello')).toBeInTheDocument();
    expect(screen.getByText('hi there')).toBeInTheDocument();
  });

  it('sends message when user clicks button', async () => {
    const user = userEvent.setup();
    mockSendMessage.mockResolvedValue(undefined);

    render(<WorkflowAIChat workflowId={workflowId} onWorkflowUpdate={onWorkflowUpdate} />);

    const input = screen.getByPlaceholderText(/������Ϣ/i);
    await user.type(input, '���ӽڵ�');
    await user.click(screen.getByRole('button', { name: /����/i }));

    await waitFor(() => {
      expect(mockSendMessage).toHaveBeenCalledWith('���ӽڵ�');
    });
  });

  it('disables input while processing', () => {
    setupHookReturn({ isProcessing: true });

    render(<WorkflowAIChat workflowId={workflowId} onWorkflowUpdate={onWorkflowUpdate} />);

    expect(screen.getByPlaceholderText(/������Ϣ/i)).toBeDisabled();
    expect(screen.getByRole('button', { name: /����/i })).toBeDisabled();
    expect(screen.getByText(/AI����˼��/i)).toBeInTheDocument();
  });

  it('shows pending workflow confirmation CTA', async () => {
    const user = userEvent.setup();
    setupHookReturn({ pendingWorkflow: { id: workflowId } });

    render(<WorkflowAIChat workflowId={workflowId} onWorkflowUpdate={onWorkflowUpdate} />);

    await user.click(screen.getByRole('button', { name: /ͬ��������/i }));

    expect(mockConfirmPending).toHaveBeenCalled();
  });

  it('displays error message from hook', () => {
    setupHookReturn({ errorMessage: '����ʧ��', messages: [] });

    render(<WorkflowAIChat workflowId={workflowId} onWorkflowUpdate={onWorkflowUpdate} />);

    expect(screen.getByText(/����ʧ��/)).toBeInTheDocument();
  });
});
