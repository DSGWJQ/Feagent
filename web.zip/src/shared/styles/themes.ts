/**
 * 主题定义 - Dark/Light主题配置
 *
 * 定义不同主题下的CSS Variable值
 * Light主题通过反转neutral颜色实现
 * 支持新古典主义设计系统
 */

import { neoclassicalColors } from './tokens/neoclassicalColors';

export type ThemeMode = 'dark' | 'light';

export interface ThemeVariables {
  // Neutral colors (主要变化的颜色)
  '--color-neutral-50': string;
  '--color-neutral-100': string;
  '--color-neutral-200': string;
  '--color-neutral-300': string;
  '--color-neutral-400': string;
  '--color-neutral-500': string;
  '--color-neutral-600': string;
  '--color-neutral-700': string;
  '--color-neutral-800': string;
  '--color-neutral-900': string;

  // Background & Border (基于neutral的语义化颜色)
  '--color-bg-primary': string;
  '--color-bg-secondary': string;
  '--color-bg-tertiary': string;
  '--color-border-primary': string;
  '--color-border-secondary': string;
  '--color-text-primary': string;
  '--color-text-secondary': string;
  '--color-text-tertiary': string;

  // Neoclassical (新古典主义变量)
  '--neo-bg': string;
  '--neo-surface': string;
  '--neo-surface-2': string;
  '--neo-text': string;
  '--neo-text-2': string;
  '--neo-border': string;
  '--neo-gold': string;
  '--neo-blue': string;
  '--neo-red': string;
  '--neo-focus': string;
}

/**
 * Dark主题配置（默认）
 */
export const darkTheme: ThemeVariables = {
  // Neutral scale
  '--color-neutral-50': '#fafafa',
  '--color-neutral-100': '#f5f5f5',
  '--color-neutral-200': '#e0e0e0',
  '--color-neutral-300': '#d0d0d0',
  '--color-neutral-400': '#9e9e9e',
  '--color-neutral-500': '#6b6b6b',
  '--color-neutral-600': '#4a4a4a',
  '--color-neutral-700': '#2e2e2e',
  '--color-neutral-800': '#1a1a1a',
  '--color-neutral-900': '#0a0a0a',

  // Semantic colors
  '--color-bg-primary': '#0a0a0a',     // neutral-900
  '--color-bg-secondary': '#1a1a1a',   // neutral-800
  '--color-bg-tertiary': '#2e2e2e',    // neutral-700
  '--color-border-primary': '#1a1a1a', // neutral-800
  '--color-border-secondary': '#2e2e2e', // neutral-700
  '--color-text-primary': '#fafafa',   // neutral-50
  '--color-text-secondary': '#9e9e9e', // neutral-400
  '--color-text-tertiary': '#6b6b6b',  // neutral-500

  // Neoclassical - Dark theme
  '--neo-bg': neoclassicalColors.themeVars.dark['--neo-bg'],
  '--neo-surface': neoclassicalColors.themeVars.dark['--neo-surface'],
  '--neo-surface-2': neoclassicalColors.themeVars.dark['--neo-surface-2'],
  '--neo-text': neoclassicalColors.themeVars.dark['--neo-text'],
  '--neo-text-2': neoclassicalColors.themeVars.dark['--neo-text-2'],
  '--neo-border': neoclassicalColors.themeVars.dark['--neo-border'],
  '--neo-gold': neoclassicalColors.themeVars.dark['--neo-gold'],
  '--neo-blue': neoclassicalColors.themeVars.dark['--neo-blue'],
  '--neo-red': neoclassicalColors.themeVars.dark['--neo-red'],
  '--neo-focus': neoclassicalColors.themeVars.dark['--neo-focus'],
};

/**
 * Light主题配置（反转neutral颜色）
 */
export const lightTheme: ThemeVariables = {
  // Neutral scale (反转)
  '--color-neutral-50': '#0a0a0a',
  '--color-neutral-100': '#1a1a1a',
  '--color-neutral-200': '#2e2e2e',
  '--color-neutral-300': '#4a4a4a',
  '--color-neutral-400': '#6b6b6b',
  '--color-neutral-500': '#9e9e9e',
  '--color-neutral-600': '#d0d0d0',
  '--color-neutral-700': '#e0e0e0',
  '--color-neutral-800': '#f5f5f5',
  '--color-neutral-900': '#fafafa',

  // Semantic colors (反转)
  '--color-bg-primary': '#fafafa',     // neutral-50
  '--color-bg-secondary': '#f5f5f5',   // neutral-100
  '--color-bg-tertiary': '#e0e0e0',    // neutral-200
  '--color-border-primary': '#e0e0e0', // neutral-200
  '--color-border-secondary': '#d0d0d0', // neutral-300
  '--color-text-primary': '#0a0a0a',   // neutral-900
  '--color-text-secondary': '#4a4a4a', // neutral-600
  '--color-text-tertiary': '#6b6b6b',  // neutral-500

  // Neoclassical - Light theme
  '--neo-bg': neoclassicalColors.themeVars.light['--neo-bg'],
  '--neo-surface': neoclassicalColors.themeVars.light['--neo-surface'],
  '--neo-surface-2': neoclassicalColors.themeVars.light['--neo-surface-2'],
  '--neo-text': neoclassicalColors.themeVars.light['--neo-text'],
  '--neo-text-2': neoclassicalColors.themeVars.light['--neo-text-2'],
  '--neo-border': neoclassicalColors.themeVars.light['--neo-border'],
  '--neo-gold': neoclassicalColors.themeVars.light['--neo-gold'],
  '--neo-blue': neoclassicalColors.themeVars.light['--neo-blue'],
  '--neo-red': neoclassicalColors.themeVars.light['--neo-red'],
  '--neo-focus': neoclassicalColors.themeVars.light['--neo-focus'],
};

/**
 * 获取主题配置
 */
export function getThemeVariables(mode: ThemeMode): ThemeVariables {
  return mode === 'dark' ? darkTheme : lightTheme;
}

/**
 * 应用主题到DOM
 */
export function applyTheme(mode: ThemeMode): void {
  const root = document.documentElement;
  const variables = getThemeVariables(mode);

  // 添加过渡class
  root.classList.add('theme-transition');

  // 应用CSS Variables
  Object.entries(variables).forEach(([key, value]) => {
    root.style.setProperty(key, value);
  });

  // 设置data-theme属性（用于CSS选择器）
  root.setAttribute('data-theme', mode);

  // 300ms后移除过渡class（避免影响其他动画）
  setTimeout(() => {
    root.classList.remove('theme-transition');
  }, 300);
}

/**
 * 从localStorage读取主题偏好
 */
export function getStoredTheme(): ThemeMode {
  const stored = localStorage.getItem('theme-preference');
  if (stored === 'light' || stored === 'dark') {
    return stored;
  }
  return 'dark'; // 默认dark主题
}

/**
 * 保存主题偏好到localStorage
 */
export function storeTheme(mode: ThemeMode): void {
  localStorage.setItem('theme-preference', mode);
}
