export { KnowledgeUploadPage } from './KnowledgeUploadPage';
