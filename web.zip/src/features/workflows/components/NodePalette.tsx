/**
 * Node Palette - 节点调色板
 *
 * 左侧面板，显示所有可用的节点类型，支持拖拽添加到画布
 * 使用CSS Module + 设计Token系统
 */

import { Card, Tooltip } from 'antd';
import {
  PlayCircleOutlined,
  CheckCircleOutlined,
  GlobalOutlined,
  MessageOutlined,
  ApartmentOutlined,
  PictureOutlined,
  SoundOutlined,
  BranchesOutlined,
  CodeOutlined,
  FileTextOutlined,
  ToolOutlined,
  DatabaseOutlined,
  FileOutlined,
  BellOutlined,
  ReloadOutlined,
} from '@ant-design/icons';
import { nodeTypeConfigs } from '../utils/nodeUtils';
import styles from '../styles/workflows.module.css';

interface NodePaletteProps {
  onAddNode: (type: string) => void;
}

const iconMap: Record<string, React.ReactNode> = {
  Play: <PlayCircleOutlined />,
  Square: <CheckCircleOutlined />,
  Globe: <GlobalOutlined />,
  MessageSquare: <MessageOutlined />,
  Layers: <ApartmentOutlined />,
  Image: <PictureOutlined />,
  Music: <SoundOutlined />,
  GitBranch: <BranchesOutlined />,
  Code: <CodeOutlined />,
  FileText: <FileTextOutlined />,
  Wrench: <ToolOutlined />,
  Database: <DatabaseOutlined />,
  File: <FileOutlined />,
  Bell: <BellOutlined />,
  Repeat: <ReloadOutlined />,
};

export default function NodePalette({ onAddNode }: NodePaletteProps) {
  const handleDragStart = (
    event: React.DragEvent<HTMLDivElement>,
    nodeType: string
  ) => {
    event.dataTransfer.setData('application/reactflow', nodeType);
    event.dataTransfer.effectAllowed = 'move';
  };

  return (
    <div className={styles.nodePalette}>
      <h3 className={styles.nodePaletteTitle}>
        节点调色板
      </h3>
      <div className={styles.nodePaletteList}>
        {nodeTypeConfigs.map((config) => (
          <Tooltip key={config.type} title={config.description} placement="right">
            <Card
              size="small"
              hoverable
              draggable
              onDragStart={(e) => handleDragStart(e, config.type)}
              onClick={() => onAddNode(config.type)}
              className={styles.nodePaletteCard}
              style={{
                borderLeft: `4px solid ${config.color}`,
              }}
              styles={{
                body: {
                  padding: '8px 12px',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 12,
                },
              }}
            >
              <div
                style={{
                  width: 32,
                  height: 32,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  borderRadius: 6,
                  backgroundColor: config.color,
                  color: '#fff',
                  fontSize: 16,
                }}
              >
                {iconMap[config.icon]}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{
                  fontSize: 14,
                  fontWeight: 500,
                  color: '#fafafa' // 浅色文字
                }}>
                  {config.label}
                </div>
                <div
                  style={{
                    fontSize: 12,
                    color: '#8c8c8c', // 灰色描述文字
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                  }}
                >
                  {config.description}
                </div>
              </div>
            </Card>
          </Tooltip>
        ))}
      </div>
    </div>
  );
}
